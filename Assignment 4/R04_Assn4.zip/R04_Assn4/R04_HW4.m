% Title: Engr 12 Assignment 4
% Authors: Kevin Pietz, Evan White, Eureka Zheng
% Date: 1.29.18

clear all;
clc;

respond='y'; %variable for while loop to run whole code again

while respond=='y' %will run code again if user wants it try again
    
    filename='ah'; %variable the represents data file input

    % Prompt the user for a data file
    while exist(filename)==0
        filename=input('Enter the data file name: ','s');
    end

    data=load(filename); % create matrix of data file
    
    % Check wether data is in rows or columns
    [rows, cols]=size(data);

    if rows<cols
        data=data';
        ro=cols;
        co=rows;
        x=data(1:ro,1);
        y=data(1:ro,2);
    else
        x=data(1:rows,1);
        y=data(1:rows,2);
    end

    

    % prompt user to select type of plot symbol with menu 
    symbol=menu('Click the symbol you want to use','point','circle','x-mark','plus','star','square','diamond','triangle(down)','triangle(up)','triangle(left)','triangle(right)','pentagram','hexagram');

    switch symbol
        case 1
            sym='.';
        case 2
            sym='o';
        case 3
            sym='x';
        case 4
            sym='+';
        case 5
            sym='*';
        case 6
            sym='s';
        case 7
            sym='d';
        case 8
            sym='v';
        case 9
            sym='^';
        case 10
            sym='<';
        case 11
            sym='>';
        case 12
            sym='p';
        case 13
            sym='h';
    end

    % prompt user for color of line
    c=1;
    while c==1
        color=input('Enter the color you would like the line to be: ','s');

        if strcmpi(color,'blue')==1 || strcmpi(color,'b')
            c='b';
        elseif strcmpi(color,'green')==1 || strcmpi(color,'g')
            c='g';
        elseif strcmpi(color,'red')==1 || strcmpi(color,'r')
            c='r';
        elseif strcmpi(color,'cyan')==1 || strcmpi(color,'c')
            c='c';
        elseif strcmpi(color,'magenta')==1 || strcmpi(color,'m')
            c='m';
        elseif strcmpi(color,'yellow')==1 || strcmpi(color,'y')
            c='y';
        elseif strcmpi(color,'black')==1 || strcmpi(color,'k')
            c='k';
        elseif strcmpi(color,'white')==1 || strcmpi(color,'w')
            c='w';    
        else
            disp('That is not a valid color. Please try again');
            c=1;
        end

    end

    % plot data
    figure
    plot(x,y,horzcat(sym,c));

    % label title, x and y axes
    heading=input('Enter the title of the graph: ','s');
    title(heading);

    bottom=input('Enter the x axis label: ','s');
    xlabel(bottom);

    left=input('Enter the y axis label: ','s');
    ylabel(left);
    
    % ask to run code again, with error check
    respond=input('Would you like to try another data file? (y/n) ','s');
    while strcmpi(respond,'y')==0 && strcmpi(respond,'n')==0
       disp('That is not a valid response. Please respond with y or n.');
       respond=input('Would you like to try another data file? (y/n) ','s');
    end
        
end
